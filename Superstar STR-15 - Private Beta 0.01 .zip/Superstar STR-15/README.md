# STR-15 (The Groupie)
by nguyenkvvn

> _"Long ago... and oh so far away..."_

Private Beta Release 0.01 - Internal Revision v35

## Description
The Groupie STR-15 is an AR-15 lower receiver designed exclusively for buffer-less upper receiver actions, and uses any Mossberg 500-series compatible stock/pistol-grip attachment.

## WARNING!
Do *NOT* under any circumstance use this design with ANY upper receiver that requires a buffer tube. Catastrophic, and FATAL, damage *WILL* occur. The designer, and any affiliated or non-affiliated groups, cannot be held responsible or liable for any injuries or damages that occur with your use of this model.

It is imperative you read this entire document before beginning this project.

## Materials Required
1. **Bufferless AR-15 Upper Receiver** - Examples include Brownells AR-180, CMNG/PSA .22LR Dedicated Receiver, or CMNG .22LR Conversion Kit.
2. **Mossberg 500 compatible stock/pistol-grip** - You can use any Mossberg 500 compatible stock, brace, pistol, or birdshead grip. _Remember not to make an NFA configuration unless you are legally allowed to do so._
3. **AR-15 Lower Parts Kit** - A lower parts kit of your choosing will do. Mil-spec is the minimum.
4. **AR-15 Fire Control Group** - You will need a _mil-spec_ AR-15 fire control group. (Sorry, no drop-in triggers!)
5. **x1 M3 x 0.5mm 8mm long Socket Head Screw** - You can find this from McMasterCarr with part number 91290A113. (You can get by without this.)

You may find that a set of files will come in handy for your specific print's fitment.

## Instructions
1. Print the receiver.
2. Print the desired trigger bow. (You can print either straight-bow or curved-bow trigger.)
3. Complete the receiver with the lower parts kit.
4. Test the fitment of the printed trigger bow. (Make sure you can put it in and out of the receiver easily!) If the fitment is successful, assemble the fire control group with the appropriate springs. Set aside the mil-spec trigger- it won't be used for this build (yet).
5. Test the fitment of the fire selector. File the receiver as necessary for a snug, but not overly tight, fit.
6. Assemble the rest of the receiver with the fire control group. Be careful not to drop the hammer onto the frame.
7. Perform a function test of the fire control group- does the hammer drop? Does the disconnector work? What about the safety?
8. Assemble the upper receiver onto the lower, and perform another function check.

## Printing Tips
* It is recommended to print the receiver _upside-down_.
* Tree supports are _not_ recommended if printing upside-down.
* eSUN PLA+ is the _required_ filament if you are using any caliber that is NOT a .22LR.
* It's recommended to print the trigger upside-down with the bow pointing up, as it will reduce the chances of the sides of your trigger snapping off when taking off the plate.
* Print HOT and SLOW for maximum bonding and strength. (50 mm/s and 230 C is recommended.)